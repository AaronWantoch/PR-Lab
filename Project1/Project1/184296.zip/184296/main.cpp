#include <string>
#include <iostream>
#include <filesystem>
namespace fs = std::filesystem;

using namespace std;

struct Folder;
struct Finfo
{
    bool isFile;
    string name;
    __int64 length;
    fs::file_time_type modificationDate;
    Folder* parent;
};

struct Folder : public Finfo
{
    list<Finfo*> children;
};

void writeFiles(Folder* folder)
{
    cout << folder->name<<endl;
    int level=0;
    for (Folder* current = folder->parent; current != NULL; current = current->parent)
        level++;
    for (Finfo* current : folder->children)
    {
        for (int i = 0; i < level; i++)
            cout << "\t";
        if (current->isFile)
            cout << current->name<<endl;
        else
            writeFiles((Folder*)current);
    }
}

Folder* getFiles(string folderName)
{
    Folder* folder = new Folder();
    for (const auto& entry : fs::directory_iterator(folderName))
    {
        Finfo* current;
        if (entry.is_directory())
        {
            current = getFiles(entry.path().string());
        }

        else
        {
            current = new Finfo();
            current->isFile = true;
            current->length = entry.file_size();
            current->modificationDate = entry.last_write_time();
            current->parent = folder;
            current->name = entry.path().string();
        }
        current->parent = folder;
        folder->children.push_back(current);
    }
    fs::directory_entry* entry = new fs::directory_entry(fs::path(folderName));
    folder->name = folderName;
    folder->isFile = false;
    folder->modificationDate = entry->last_write_time();
    folder->length = entry->file_size();
    folder->parent = NULL;
    delete entry;
    return folder;
}


int main()
{
    string path = "C:\\Riot Games";
    Folder* folder = getFiles(path);
    writeFiles(folder);

}